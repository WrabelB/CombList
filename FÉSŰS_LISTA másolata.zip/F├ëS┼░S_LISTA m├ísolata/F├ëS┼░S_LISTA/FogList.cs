﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FÉSŰS_LISTA
{
    internal class FogList
    {
        FogNode head;
        int count;
        public int Count
        {
            get { return count; }
        }
        public FogList()
        {
            head = null;
            count = 0;
        }
        public FogList(int data)
        {
            head = new FogNode(data);
            count = 1;
        }

        public FogList(FogList other)
        {
            this.head = new FogNode((int)other[0]);

            FogNode q = head;
            for (FogNode p = other.head.Next; p != null; p = p.Next)
            {
                q.Next = new FogNode(p.Data);
                q = q.Next;
            }
        }

        public override string ToString()
        {
            string s = "";

            for (FogNode p = head; p != null; p = p.Next)
                s += p.Data + " ---> ";

            s += "null";
            return s;
        }

        public void AddLast(int newData)
        {
            count++;
            // ha üres a lista
            if (head == null)
            {
                head = new FogNode(newData);
                return;
            }

            // elmegyünk a lista végére
            FogNode p = head;
            while (p.Next != null)
                p = p.Next;

            // az utolsó elem után fűzzük az új elemet
            p.Next = new FogNode(newData);
        }

        public void AddFirst(int newData)
        {
            count++;
            // ha üres a lista                                    
            if (head == null)
            {
                head = new FogNode(newData);
                return;
            }


            FogNode uj = new FogNode(newData);    // 1                  
            uj.Next = head;                 // 2                  
            head = uj;                      // 3                  
        }

        public int? this[int index]
        {
            get
            {
                if (index < 0 || index >= Count)
                    return null;

                FogNode p = head;
                for (int i = 0; i != index; p = p.Next, i++) ;
                return p.Data;
            }
            set
            {
                if (index >= 0 && index < Count)
                {
                    FogNode p = head;
                    for (int i = 0; i != index; p = p.Next, i++) ;
                    p.Data = (int)value;
                }
            }
        }

        // Házi feladat:
        // 1.: indexen lévő elemet törli a listából
        public void RemoveItemByIndex(int index)
        {
            if (index < 0 || index >= Count)
                return;
            count--;

            if (Count == 1)
            {
                head = null;
                return;
            }

            if (index == 0)
            {
                head = head.Next;
                return;
            }

            FogNode p = head;
            for (int i = 0; i != index - 1; p = p.Next, i++) ;
            p.Next = p.Next.Next;


        }
        // 2.: Paraméterben kapott értékű elemeket(összeset) törli a listából
        public void RemoveItemByValue(int value)
        {
            if (Iselement(value))
                RemoveItem(value);
        }

        private void RemoveItem(int value)
        {
            count--;
            if (head.Data == value)
            {
                head = head.Next;
                return;
            }

            FogNode p = head;
            while (p.Next.Data != value) { p = p.Next; }

            p.Next = p.Next.Next;
        }


        public bool Iselement(int value)
        {
            for (FogNode p = head; p != null; p = p.Next)
                if (p.Data == value)
                    return true;

            return false;
        }


        public FogNode GetHead() { return head; }
  
        //novekvo
        public void Sort()
        {
            for (FogNode i = head; i.Next != null; i = i.Next)
            {
                for (FogNode j = i.Next; j != null; j = j.Next)
                {
                    if (j.Data < i.Data)
                    {
                        Replace(j, i);
                    }
                }
            }
        }

        private void Replace(FogNode a, FogNode b)
        {
            int tmp = a.Data;
            a.Data = b.Data;
            b.Data = tmp;
        }

        public static FogList Sort(FogList lista)
        {
            FogList rendezett = new FogList(lista);
            rendezett.Sort();
            return rendezett;
        }
    }
}
