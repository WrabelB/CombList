﻿using System.Xml.Linq;

namespace FÉSŰS_LISTA
{
    internal class GerincList
    {
        GerincNode head;
        int count;
        public int Count
        {
            get { return count; }
        }
        public GerincList()
        {
            head = null;
            count = 0;
        }
        public GerincList(int data)
        {
            head = new GerincNode(data);
            count = 1;
        }
        public GerincList(GerincList other)
        {
            this.head = new GerincNode(other.GetByIndex(0));

            GerincNode q = head;
            for (GerincNode p = other.head.Next; p != null; p = p.Next)
            {
                q.Next = new GerincNode(p.Data);
                q = q.Next;
            }
        }

        public override string ToString()
        {
            string s = "";

            for (GerincNode p = head; p != null; p = p.Next)
                s += p.Data + " :: " + p.Fog + "\n";

            s += " - null - ";
            return s;
        }

        public void AddFirst(int newGerincData)
        {
            count++;
            if (head == null)
            {
                head = new GerincNode(newGerincData);
                return;
            }

            GerincNode ujgerinc = new GerincNode(newGerincData);
            ujgerinc.Next = head;
            head = ujgerinc;

        }

        public void AddLast(int newGerincData)
        {
            count++;
            if (head == null)
            {
                head = new GerincNode(newGerincData);
                return;
            }

            GerincNode p = head;
            while (p.Next != null)
                p = p.Next;

            p.Next = new GerincNode(newGerincData);

        }

        public void AddFirstFog(int gerincAzonosito, int newFogData)
        {

            if (head == null)
            {
                head = new GerincNode(gerincAzonosito);
                head.Fog.AddFirst(newFogData);
                count++;
                return;
            }

            if (!Iselement(gerincAzonosito))
            {
                this.AddFirst(gerincAzonosito);
                head.Fog.AddFirst(newFogData);
                count++;
                return;
            }
            GerincNode gerinc = head;
            while (gerinc.Next.Data != gerincAzonosito)
            {
                gerinc = gerinc.Next;
            }
            gerinc.Next.Fog.AddFirst(newFogData);
        }

        public void AddLastFog(int gerincAzonosito, int newFogData)
        {
            if (head == null)
            {
                head = new GerincNode(gerincAzonosito);
                head.Fog.AddFirst(newFogData);
                count++;
            }

            if (!Iselement(gerincAzonosito))
            {
                this.AddLast(gerincAzonosito);
                head.Fog.AddLast(newFogData);
                count++;
                return;
            }

            GerincNode gerinc = head;
            while (gerinc.Next.Data != gerincAzonosito)
            {
                gerinc = gerinc.Next;
            }
            gerinc.Next.Fog.AddLast(newFogData);

        }

        public bool Iselement(int value)
        {
            for (GerincNode p = head; p != null; p = p.Next)
                if (p.Data == value)
                    return true;

            return false;
        }


        public int? GetByIndex(int index)
        {
            if (index < 0 || index >= Count)
                return null;

            GerincNode p = head;
            for (int i = 0; i != index; p = p.Next, i++) ;
            return p.Data;
        }

        public FogList GetNodeByIndex(int index)
        {
            if (index < 0 || index >= Count)
                return null;

            GerincNode p = head;
            for (int i = 0; i != index; p = p.Next, i++) ;
            return p.Fog;
        }

        public void SetByIndex(int index, int value)
        {
            if (index >= 0 && index < Count)
            {
                GerincNode p = head;
                for (int i = 0; i != index; p = p.Next, i++) ;
                p.Data = (int)value;
            }
        }

        public void RemoveGerincByIndex(int index)
        {
            if (index < 0 || index >= Count)
                return;
            count--;

            if (Count == 1)
            {
                head = null;
                return;
            }

            if (index == 0)
            {
                head = head.Next;
                return;
            }

            GerincNode p = head;
            for (int i = 0; i != index - 1; p = p.Next, i++) ;
            p.Next = p.Next.Next;

        }

        public void RemoveFogByIndex(int indexGerinc, int indexFog)
        {
            if (indexGerinc < 0 && indexFog < 0 || indexGerinc >= Count)
                return;

            FogList fogList = GetNodeByIndex(indexGerinc);
            fogList.RemoveItemByIndex(indexFog);
        }


        public void Sort()
        {

            for (GerincNode i = head; i.Next != null; i = i.Next)
            {
                for (GerincNode j = i.Next; j != null; j = j.Next)
                {
                    if (j.Data < i.Data)
                    {
                        Replace(j, i);

                    }
                }
            }
            for (GerincNode i = head; i.Next != null; i = i.Next)
            {
                if (i.Fog.GetHead() != null)
                    i.Fog.Sort();
            }
        }

        private void Replace(GerincNode a, GerincNode b)
        {
            int tmp = a.Data;
            a.Data = b.Data;
            b.Data = tmp;

            FogList fog = a.Fog;
            a.Fog = b.Fog;
            b.Fog = fog;
        }

        public void RemoveItemByValueGerinc(int value)
        {
            if (Iselement(value))
                RemoveGerincItem(value);
        }
        private void RemoveGerincItem(int value)
        {
            count--;
            if (head.Data == value)
            {
                head = head.Next;
                return;
            }

            GerincNode p = head;
            while (p.Next.Data != value) { p = p.Next; }

            p.Next = p.Next.Next;
        }
        

        public void RemoveFogByValue(int gerincElem, int fogElem)
        {
            for (GerincNode gn = head; gn != null; gn = gn.Next)
            {
                if (gn.Data == gerincElem && gn.Fog.Iselement(fogElem))
                {
                    gn.Fog.RemoveItemByValue(fogElem);
                    return;
                }
            }
        }
    }
}
