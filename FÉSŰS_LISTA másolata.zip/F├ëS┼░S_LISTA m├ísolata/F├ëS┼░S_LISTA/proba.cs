﻿namespace FÉSŰS_LISTA
{
    class proba
    {
        FogNode head;
        int count;

        public int Count
        {
            get { return count; }
        }

        public proba()
        {
            head = null;
            count = 0;
        }

        public proba(int data)
        {
            head = new FogNode(data);
            count = 1;
        }

        public proba(proba other)
        {
            this.head = new FogNode(other.head.Data);

            FogNode q = head;
            for (FogNode p = other.head.Next; p != null; p = p.Next)
            {
                q.Next = new FogNode(p.Data);
                q = q.Next;
            }

            count = other.Count;
        }

        public override string ToString()
        {
            string s = "";

            for (FogNode p = head; p != null; p = p.Next)
                s += p.Data + " -> ";

            s += "null";
            return s;
        }

        public void AddLast(int newData)
        {
            count++;
            // ha üres a lista
            if (head == null)
            {
                head = new FogNode(newData);
                return;
            }

            // elmegyünk a lista végére
            FogNode p = head;
            while (p.Next != null)
                p = p.Next;

            // az utolsó elem után fűzzük az új elemet
            p.Next = new FogNode(newData);
        }

        public void AddFirst(int newData)
        {
            count++;
            // ha üres a lista                                    
            if (head == null)
            {
                head = new FogNode(newData);
                return;
            }

            FogNode newNode = new FogNode(newData);
            newNode.Next = head;
            head = newNode;
        }

        public void RemoveItemByValue(int value)
        {
            FogNode prev = null;
            FogNode current = head;

            while (current != null)
            {
                if (current.Data == value)
                {
                    if (prev == null)
                    {
                        // Az első elemet kell törölni
                        head = current.Next;
                    }
                    else
                    {
                        // Egy köztes vagy utolsó elemet kell törölni
                        prev.Next = current.Next;
                    }

                    count--;
                    return;
                }

                prev = current;
                current = current.Next;
            }
        }

        public void RemoveItemByIndex(int index)
        {
            if (index < 0 || index >= Count)
                return;

            count--;

            if (index == 0)
            {
                head = head.Next;
                return;
            }

            FogNode prev = null;
            FogNode current = head;

            for (int i = 0; i < index; i++)
            {
                prev = current;
                current = current.Next;
            }

            prev.Next = current.Next;
        }

        public void Sort()
        {
            for (FogNode i = head; i != null; i = i.Next)
            {
                for (FogNode j = i.Next; j != null; j = j.Next)
                {
                    if (j.Data < i.Data)
                    {
                        Replace(j, i);
                    }
                }
            }
        }

        private void Replace(FogNode a, FogNode b)
        {
            int tmp = a.Data;
            a.Data = b.Data;
            b.Data = tmp;
        }

        // Fog és gerinc kezelésére szolgáló metódusok
        public void AddTooth(int toothData)
        {
            AddLast(toothData);
        }

        public void AddSpine(int spineData)
        {
            AddLast(spineData);
        }

        public void RemoveTooth(int toothData)
        {
            RemoveItemByValue(toothData);
        }

        public void RemoveSpine(int spineData)
        {
            RemoveItemByValue(spineData);
        }
    }
}
