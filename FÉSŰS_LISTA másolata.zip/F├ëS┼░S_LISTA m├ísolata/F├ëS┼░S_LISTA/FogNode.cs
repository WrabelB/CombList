﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FÉSŰS_LISTA
{
    internal class FogNode
    {
        int data;
        FogNode next;

        public int Data
        {
            get { return data; }
            set { data = value; }
        }
        public FogNode Next
        {
            get { return next; }
            set { next = value; }
        }
        public FogNode(int data)
        {
            this.data = data;
            next = null;
        }
    }
}
