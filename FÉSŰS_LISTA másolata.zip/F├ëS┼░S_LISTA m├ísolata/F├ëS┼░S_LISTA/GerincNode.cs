﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FÉSŰS_LISTA
{
    internal class GerincNode
    {
        int data;
        GerincNode next;
        FogList fog;

        public int Data
        {
            get { return data; }
            set { data = value; }
        }
        public GerincNode Next
        {
            get { return next; }
            set { next = value; }
        }
        public GerincNode(int? data)
        {
            this.data = (int)data;
            next = null;
            fog = new FogList();
        }

        public FogList Fog
        {
            get { return fog; }
            set { fog = value; }
        }


    }
}
