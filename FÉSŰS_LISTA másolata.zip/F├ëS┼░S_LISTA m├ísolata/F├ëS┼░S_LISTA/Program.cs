﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FÉSŰS_LISTA
{
    class Program
    {
        static void Main(string[] args)
        {
            GerincList gerinc = new GerincList();
            gerinc.AddFirst(20);
            gerinc.AddFirst(8);
            gerinc.AddFirst(6);
            gerinc.AddFirst(10);
            gerinc.AddFirst(11);
            gerinc.AddLastFog(10, 22);
            gerinc.AddFirstFog(20, 5);
            gerinc.AddFirstFog(10, 50);
            gerinc.AddFirstFog(10, 60);
            gerinc.AddFirstFog(6, 60);
            gerinc.AddFirstFog(6, 11);
            gerinc.AddFirstFog(6, 67);
            gerinc.AddFirstFog(6, 550);


            gerinc.AddLast(99);
            Console.WriteLine(gerinc);
            Console.WriteLine(" -- TORLES INDEX-- ");
            Console.WriteLine();
            gerinc.RemoveGerincByIndex(1);
            gerinc.RemoveFogByIndex(1, 1);
            Console.WriteLine(gerinc);

            Console.WriteLine(" -- SORT -- ");
            gerinc.Sort();
            Console.WriteLine(gerinc);

            Console.WriteLine(" -- TORLES VALUE GERINC--");
            gerinc.RemoveItemByValueGerinc(6);
            Console.WriteLine(gerinc);
            Console.WriteLine();
            Console.WriteLine(" -- TORLES VALUE FOG --");
            gerinc.RemoveFogByValue(20,5);
            Console.WriteLine(gerinc);











            /*proba toothAndSpineList = new proba();

            toothAndSpineList.AddTooth(5);
            toothAndSpineList.AddSpine(10);
            toothAndSpineList.AddTooth(3);
            toothAndSpineList.AddSpine(8);

            Console.WriteLine("Eredeti lista:");
            Console.WriteLine(toothAndSpineList.ToString());

            toothAndSpineList.RemoveTooth(5);
            toothAndSpineList.RemoveSpine(8);

            Console.WriteLine("\nMódosított lista:");
            Console.WriteLine(toothAndSpineList.ToString());

            toothAndSpineList.Sort();

            Console.WriteLine("\nRendezett lista:");
            Console.WriteLine(toothAndSpineList.ToString());

            Console.ReadLine();*/
        }
    }
}
